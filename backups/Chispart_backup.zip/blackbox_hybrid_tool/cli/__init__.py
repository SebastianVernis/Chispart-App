"""
Módulo CLI de Blackbox Hybrid Tool
Contiene la interfaz de línea de comandos
"""

from .main import CLI, main

__all__ = ['CLI', 'main']
