"""
Tests para Blackbox Hybrid Tool
"""
