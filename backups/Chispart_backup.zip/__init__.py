"""
Blackbox Hybrid Tool - Herramienta híbrida de testing y análisis de código con IA
"""

__version__ = "0.1.0"
__author__ = "Blackbox AI"
__email__ = "info@blackbox.ai"
